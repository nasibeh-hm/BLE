# BLE-Scenarios
This open source project is about BLE testing scenarios for evaluating the functionality of different BLE versions.
In a scenario, phone requests for starting scenario and then module on board starts to 20 times sending a set of 100 strings which each string contains 5 character. After phone receives all 2000 strings starts to evaluate the Correctness of them and reports packet loss percent(PLP).Furthermore timestamp of Scenario's start and end is stored.
